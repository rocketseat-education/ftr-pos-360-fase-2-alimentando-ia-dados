import "./ThinkingIndicator.css";

export default function ThinkingIndicator() {
  return (
    <>
      <div className="thinking-indicator">
        <div className="thinking-ball"></div>
      </div>
    </>
  );
}
